import productDAO from "../DAO/productdao.js";
export const getAll = (req, res) => {
    productDAO.getAll()
        .then(products => res.render('../src/views/index', {products}))
        .catch(err => res.json({
            status: "Server unavailable"
        })
        );
};
export const getOne = (req, res) => {
    productDAO.getOne(req.params.barcode)
        .then(result => {
            !result ? res.json({
                message: "product not found :/"
            }) : res.render('../src/views/edit.ejs',{product});
        })
        .catch(err => res.json({
            status: "Server unavailable"
        })
        );
};
export const insertOne = (req, res) => {
    console.log(req.body);
    productDAO.insertOne(req.body)
        .then(result => res.redirect('/api/products/',{product}))
        .catch(err => res.json({ status: "Server unavailable" }));
};

export const updateOne = (req, res) => {
    productDAO.updateOne(req.params.barcode, req.body)
        .then(result => res.json({ status: "Product update" }))
        .catch(err => res.json({ status: "Server unavailable" }));
};
